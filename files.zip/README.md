# みどりの三尾精霊 — クラウド自動生成パイプライン

同じキャラ（LoRAで固定）を、クラウド上で「画像→動画→字幕→9:16書き出し」まで自動生成する仕組み。
完成クリップは GitHub Actions の成果物として出るので、**確認してから自分で投稿**する（最初は人間ゲートを残す）。

## 全体の流れ
```
shotlist.csv（毎回いじる）
   → LoRAでキーフレーム画像（キャラ固定） … fal: flux-lora
   → Kling で image-to-video（動かす）   … fal: kling-video
   → ffmpeg で 9:16 整形＋字幕を後焼き込み
   → output/*.mp4（Actionsの成果物）→ 確認 → 投稿
```

## 準備（君がやる・鍵は必ず自分の手で）
1. **fal.ai** に登録 → 支払い設定 → API キーを発行
2. **GitHub** に登録 → このフォルダ一式をアップした空リポジトリを作る（Private推奨）
3. リポジトリの **Settings → Secrets and variables → Actions** に登録:
   - `FAL_KEY` … falのキー
   - `LORA_URL` … 最初は空でOK（下の学習後に登録）
4. `training_images/` に学習用画像を **20〜30枚** 入れてコミット
   （= model-sheet-prompts の③で作った、角度・表情・ポーズを散らしたデータ）

## 使い方
### ① LoRAを学習（最初の1回）
Actions タブ → **train-lora** → Run workflow。
完了したらログ末尾の `LORA_URL=...` をコピーして、Secret `LORA_URL` に登録。
（これで「何度でも同じ子」が出せる土台が完成）

### ② 量産
`shotlist.csv` を編集（ネタ・動き・字幕を書くだけ＝**変える層**）。
Actions タブ → **generate-batch** → Run workflow（または毎週自動実行）。
完了後、その実行の **Artifacts (clips-◯◯)** をダウンロードして中身を確認。

### ③ 投稿
OKなクリップだけ、Instagramに投稿（手動 or 予約投稿ツール）。
トレンド音源はInstagramアプリ側で付けるのが手軽。

## ループ（運用が回り出したら）
投稿 → 数値を見る（再生・保存・コメント） → 効いた要素を `shotlist.csv` の作り方に反映。
**キャラ（LoRA）と CHAR_CORE は変えない**。いじるのは shotlist と、必要なら motion_prompt の言い回しだけ。
※数値の分析・最適化は姉妹の仕組み（sns-growth-loop）に渡すと精度が上がる。

## だいたいの費用感（2026年時点・要確認）
- 画像（flux-lora）: 約 $0.035 / メガピクセル
- 動画（Kling 2.1 standard）: 5秒で約 $0.28（上位モデルはもっと高い）
- LoRA学習: 1回 数ドル程度
※従量課金。falのダッシュボードで上限アラートを設定しておくと安心。

## 正直な注意
- **完全無人投稿はこの器に入れていない**。変な生成が混じった時に止められるよう、確認ゲートをわざと残してある。自動投稿はInstagramのapp/トークン設定を自分で用意してから別途。
- 「1日20分」は基盤完成後の定常運用の平均。学習やプロンプト調整の初期はもっとかかる。
- Klingはバージョンで画像パラメータ名が違う（v2.1=`image_url` / v2.6・v3=`start_image_url`）。モデルを変える時は `VIDEO_IMAGE_PARAM` も合わせる。
- 字幕が文字化けする時はCJKフォントのパス（`CAPTION_FONT`）を確認。
- APIや料金は変わるので、falの最新ドキュメントで都度確認を。

## ファイル
- `train_lora.py` … LoRA学習
- `pipeline.py` … 量産本体
- `shotlist.csv` … 毎回いじる入力（変える層）
- `.github/workflows/train-lora.yml` … 学習の手動実行
- `.github/workflows/generate-batch.yml` … 量産の手動/定期実行
- `training_images/` … 学習用画像を入れる場所
